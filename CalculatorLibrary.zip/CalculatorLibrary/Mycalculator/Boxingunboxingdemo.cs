﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorLibrary
{
	class Boxingunboxingdemo
	{
		static void Main(string[] args)
		{
			int a = 10;
			string srt = a.ToString();

			string str = "sonal";
			int b = int.Parse(str);
		}
	}
}
